from flask import Flask, render_template, request, jsonify
import json
import os
from datetime import datetime

app = Flask(__name__)
app.config['JSON_SORT_KEYS'] = False

# Dados armazenados em arquivo JSON
DATA_FILE = 'dados.json'

def load_data():
    """Carrega todos os dados do arquivo JSON"""
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {'projects': [], 'products': []}

def save_data(data):
    """Salva dados no arquivo JSON"""
    with open(DATA_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

# Funções de cálculo
def round_up_standard(value, ratings):
    """Arredonda para o próximo valor padrão"""
    return next((r for r in ratings if value <= r), ratings[-1])

def get_cable_size(current):
    """Retorna o tamanho do cabo baseado na corrente"""
    if current <= 20: return '2,5 mm²'
    if current <= 32: return '4 mm²'
    if current <= 45: return '6 mm²'
    if current <= 60: return '10 mm²'
    if current <= 80: return '16 mm²'
    if current <= 100: return '25 mm²'
    if current <= 125: return '35 mm²'
    if current <= 150: return '50 mm²'
    return '70 mm² ou mais'

def get_breaker_size(current):
    """Retorna tamanho do disjuntor padrão"""
    standard_ratings = [10, 16, 20, 25, 32, 40, 50, 63, 80, 100, 125, 160, 200]
    return f"{round_up_standard(current, standard_ratings)} A"

def get_contactor_rating(current):
    """Retorna dimensão do contator"""
    standard_ratings = [9, 12, 18, 25, 32, 40, 50, 65, 80, 95, 115, 150]
    return f"{round_up_standard(current * 1.2, standard_ratings)} A"

def get_terminal_block(current):
    """Retorna dimensão dos bornes de terminação"""
    if current <= 20: return 'Bornes 2,5 mm² / 4 mm²'
    if current <= 40: return 'Bornes 6 mm²'
    if current <= 63: return 'Bornes 10 mm²'
    if current <= 100: return 'Bornes 16 mm²'
    return 'Bornes 25 mm² ou superior'

def get_motor_current(partida):
    """Calcula corrente do motor"""
    if partida['inputMode'] == 'current':
        return float(partida['currentInput'])
    
    power = float(partida['power'])
    voltage = float(partida['voltage'])
    pf = float(partida['pf'])
    eff = float(partida['eff'])
    
    return (power * 1000) / (voltage * (3 ** 0.5) * pf * eff)

def get_components(partida, current):
    """Gera lista de componentes conforme tipo de partida"""
    terminal_block = get_terminal_block(current)
    starter_type = partida['starterType']
    has_redundancy = partida.get('hasRedundancy', False)
    
    components = []
    
    if starter_type == 'dir':
        components = [
            {'label': 'Contator principal', 'value': f"Contator 3P {get_contactor_rating(current)} A"},
            {'label': 'Relé térmico', 'value': f"Relé térmico ajustado para {round(current * 1.2)} A"},
            {'label': 'Disjuntor de proteção da partida', 'value': get_breaker_size(current)},
            {'label': 'Bornes', 'value': terminal_block},
        ]
        if has_redundancy:
            components.append({'label': 'Contator redundante', 'value': f"Contator 3P {get_contactor_rating(current)} A"})
    
    elif starter_type == 'y-d':
        k_current = current * 0.58
        components = [
            {'label': 'Contator estrela (K1)', 'value': f"Contator 3P {get_contactor_rating(k_current)} A"},
            {'label': 'Contator delta (K2)', 'value': f"Contator 3P {get_contactor_rating(k_current)} A"},
            {'label': 'Contator auxiliar (K3)', 'value': f"Contator 3P {get_contactor_rating(current / 3)} A"},
            {'label': 'Relé térmico', 'value': f"Relé térmico ajustado para {round(k_current)} A"},
            {'label': 'Disjuntor de proteção da partida', 'value': get_breaker_size(current)},
            {'label': 'Bornes', 'value': terminal_block},
        ]
        if has_redundancy:
            components.append({'label': 'Contator redundante', 'value': f"Contator 3P {get_contactor_rating(current)} A"})
    
    elif starter_type == 'soft':
        components = [
            {'label': 'Soft starter', 'value': f"Soft starter compatível com {current:.2f} A"},
            {'label': 'Relé térmico', 'value': 'Relé térmico com proteção de sobrecarga'},
            {'label': 'Disjuntor de proteção da partida', 'value': get_breaker_size(current)},
            {'label': 'Bornes', 'value': terminal_block},
        ]
        if has_redundancy:
            components.append({'label': 'Contator redundante', 'value': f"Contator 3P {get_contactor_rating(current)} A"})
    
    elif starter_type == 'inverter':
        voltage = partida.get('voltage', '380')
        components = [
            {'label': 'Inversor de frequência', 'value': f"Inversor compatível com {voltage} V e {current:.2f} A"},
            {'label': 'Proteção', 'value': 'Proteção eletrônica integrada'},
            {'label': 'Disjuntor de proteção da partida', 'value': get_breaker_size(current)},
            {'label': 'Bornes', 'value': terminal_block},
        ]
        if has_redundancy:
            components.append({'label': 'Contator redundante', 'value': f"Contator 3P {get_contactor_rating(current)} A"})
    
    return components

# Rotas
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/projects', methods=['GET'])
def get_projects():
    """Retorna lista de projetos salvos"""
    data = load_data()
    return jsonify(data['projects'])

@app.route('/api/projects', methods=['POST'])
def create_project():
    """Cria novo projeto"""
    data = load_data()
    project = {
        'id': len(data['projects']) + 1,
        'name': request.json.get('name', 'Novo Projeto'),
        'created': datetime.now().isoformat(),
        'partidas': []
    }
    data['projects'].append(project)
    save_data(data)
    return jsonify(project), 201

@app.route('/api/projects/<int:project_id>/partidas', methods=['POST'])
def add_partida(project_id):
    """Adiciona nova partida ao projeto"""
    data = load_data()
    
    for project in data['projects']:
        if project['id'] == project_id:
            partida = request.json
            partida['id'] = len(project['partidas']) + 1
            current = get_motor_current(partida)
            partida['current'] = round(current, 2)
            partida['components'] = get_components(partida, current)
            project['partidas'].append(partida)
            save_data(data)
            return jsonify(partida), 201
    
    return jsonify({'error': 'Projeto não encontrado'}), 404

@app.route('/api/projects/<int:project_id>/partidas/<int:partida_id>', methods=['DELETE'])
def delete_partida(project_id, partida_id):
    """Remove partida do projeto"""
    data = load_data()
    
    for project in data['projects']:
        if project['id'] == project_id:
            project['partidas'] = [p for p in project['partidas'] if p['id'] != partida_id]
            save_data(data)
            return '', 204
    
    return jsonify({'error': 'Projeto não encontrado'}), 404

@app.route('/api/projects/<int:project_id>/summary', methods=['GET'])
def get_summary(project_id):
    """Calcula resumo do painel para o projeto"""
    data = load_data()
    
    for project in data['projects']:
        if project['id'] == project_id:
            if not project['partidas']:
                return jsonify({'error': 'Nenhuma partida adicionada'}), 400
            
            fator = float(request.args.get('fator', 1))
            total_current = sum(p['current'] for p in project['partidas'])
            total_with_factor = total_current * fator
            
            summary = {
                'totalCurrent': round(total_current, 2),
                'fator': fator,
                'totalWithFactor': round(total_with_factor, 2),
                'panelBreaker': get_breaker_size(total_with_factor),
                'panelCable': get_cable_size(total_with_factor),
                'hasRedundancy': any(p.get('hasRedundancy', False) for p in project['partidas'])
            }
            return jsonify(summary)
    
    return jsonify({'error': 'Projeto não encontrado'}), 404

@app.route('/api/products', methods=['GET'])
def get_products():
    """Retorna lista de produtos cadastrados"""
    data = load_data()
    return jsonify(data['products'])

@app.route('/api/products', methods=['POST'])
def add_product():
    """Adiciona novo produto"""
    data = load_data()
    product = {
        'id': len(data['products']) + 1,
        'code': request.json.get('code'),
        'name': request.json.get('name'),
        'component': request.json.get('component'),
        'quantity': request.json.get('quantity'),
        'unitValue': request.json.get('unitValue')
    }
    data['products'].append(product)
    save_data(data)
    return jsonify(product), 201

if __name__ == '__main__':
    app.run(debug=True, port=5000)

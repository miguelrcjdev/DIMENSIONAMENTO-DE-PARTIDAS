let currentProject = null;
let projects = [];

// Tema
function initTheme() {
  const html = document.documentElement;
  const themeToggle = document.getElementById('themeToggle');
  
  const savedTheme = localStorage.getItem('theme-preference') || 'light';
  if (savedTheme === 'dark') {
    html.classList.add('dark-mode');
    themeToggle.textContent = '☀️';
  } else {
    html.classList.remove('dark-mode');
    themeToggle.textContent = '🌙';
  }
  
  themeToggle.addEventListener('click', () => {
    html.classList.toggle('dark-mode');
    const isDark = html.classList.contains('dark-mode');
    localStorage.setItem('theme-preference', isDark ? 'dark' : 'light');
    themeToggle.textContent = isDark ? '☀️' : '🌙';
  });
}

// API Calls
async function loadProjects() {
  try {
    const response = await fetch('/api/projects');
    projects = await response.json();
    
    if (projects.length === 0) {
      await createNewProject();
    } else {
      currentProject = projects[0];
      renderProject();
    }
  } catch (error) {
    console.error('Erro ao carregar projetos:', error);
  }
}

async function createNewProject() {
  try {
    const response = await fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: `Projeto ${new Date().toLocaleDateString()}` })
    });
    currentProject = await response.json();
    projects.push(currentProject);
    renderProject();
  } catch (error) {
    console.error('Erro ao criar projeto:', error);
  }
}

async function addPartida(formData) {
  if (!currentProject) return;
  
  try {
    const partida = {
      inputMode: formData.get('inputMode'),
      power: formData.get('power') || 0,
      currentInput: formData.get('currentInput') || 0,
      voltage: formData.get('voltage'),
      pf: formData.get('powerFactor') || 0.85,
      eff: formData.get('efficiency') || 0.92,
      starterType: formData.get('starterType'),
      hasRedundancy: formData.get('hasRedundancy') === 'on'
    };
    
    const response = await fetch(`/api/projects/${currentProject.id}/partidas`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(partida)
    });
    
    const newPartida = await response.json();
    currentProject.partidas.push(newPartida);
    renderProject();
    document.getElementById('partidaForm').reset();
    updateInputMode();
  } catch (error) {
    console.error('Erro ao adicionar partida:', error);
  }
}

async function removePartida(partidaId) {
  if (!currentProject) return;
  
  try {
    await fetch(`/api/projects/${currentProject.id}/partidas/${partidaId}`, {
      method: 'DELETE'
    });
    
    currentProject.partidas = currentProject.partidas.filter(p => p.id !== partidaId);
    renderProject();
  } catch (error) {
    console.error('Erro ao remover partida:', error);
  }
}

// UI Updates
function updateInputMode() {
  const inputMode = document.getElementById('inputMode').value;
  const powerLabel = document.getElementById('powerInputLabel');
  const currentLabel = document.getElementById('currentInputLabel');
  const pfLabel = document.getElementById('pfLabel');
  const effLabel = document.getElementById('effLabel');
  
  if (inputMode === 'power') {
    powerLabel.style.display = 'block';
    currentLabel.style.display = 'none';
    pfLabel.style.display = 'block';
    effLabel.style.display = 'block';
  } else {
    powerLabel.style.display = 'none';
    currentLabel.style.display = 'block';
    pfLabel.style.display = 'none';
    effLabel.style.display = 'none';
  }
}

function renderProject() {
  renderPartidas();
  renderResults();
}

function renderPartidas() {
  const container = document.getElementById('partidasList');
  
  if (!currentProject || currentProject.partidas.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <p>Nenhuma partida adicionada. Preencha o formulário e clique em "Adicionar".</p>
      </div>
    `;
    return;
  }
  
  container.innerHTML = currentProject.partidas.map(partida => `
    <div class="partida-item animate-in">
      <div class="partida-info">
        <p><strong>Tipo:</strong> ${getStarterTypeLabel(partida.starterType)}</p>
        <p><strong>Corrente:</strong> ${partida.current} A</p>
        ${partida.hasRedundancy ? '<p>🔄 Redundância ativada</p>' : ''}
      </div>
      <button class="btn-danger" onclick="removePartida(${partida.id})">✕</button>
    </div>
  `).join('');
}

function renderResults() {
  const container = document.getElementById('resultsContainer');
  
  if (!currentProject || currentProject.partidas.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <p>Adicione partidas para ver os resultados</p>
      </div>
    `;
    return;
  }
  
  let html = '';
  
  currentProject.partidas.forEach((partida, index) => {
    html += `
      <div class="card">
        <h2>Partida ${index + 1} - ${getStarterTypeLabel(partida.starterType)}</h2>
        <ul class="components-list">
          ${partida.components.map(comp => `
            <li class="component-item">
              <span class="component-label">${comp.label}</span>
              <span class="component-value">${comp.value}</span>
            </li>
          `).join('')}
        </ul>
      </div>
    `;
  });
  
  // Summary
  const fator = parseFloat(document.getElementById('fatorCagaco').value) || 1;
  const totalCurrent = currentProject.partidas.reduce((sum, p) => sum + p.current, 0);
  const totalWithFactor = totalCurrent * fator;
  
  html += `
    <div class="card" style="margin-top: 24px; background: linear-gradient(135deg, rgba(5, 150, 105, 0.05) 0%, rgba(0, 82, 204, 0.05) 100%); border-left: 4px solid var(--success);">
      <h2 style="color: var(--success);">📊 Resumo do Painel</h2>
      <div class="summary-item">
        <strong>Somatório das correntes:</strong>
        <span class="summary-value">${totalCurrent.toFixed(2)} A</span>
      </div>
      <div class="summary-item">
        <strong>FATOR CAGAÇO:</strong>
        <span class="summary-value">${fator}</span>
      </div>
      <div class="summary-item">
        <strong>Corrente total com fator:</strong>
        <span class="summary-value">${totalWithFactor.toFixed(2)} A</span>
      </div>
      <div class="summary-item">
        <strong>Disjuntor de entrada:</strong>
        <span class="summary-value">${getCableSizeFromCurrent(totalWithFactor)}</span>
      </div>
      <div class="summary-item">
        <strong>Cabo de alimentação:</strong>
        <span class="summary-value">${getBreakerFromCurrent(totalWithFactor)}</span>
      </div>
    </div>
  `;
  
  container.innerHTML = html;
}

// Helper Functions
function getStarterTypeLabel(type) {
  const labels = {
    'dir': '⚙️ Direta',
    'y-d': '⭐ Estrela-Triângulo',
    'soft': '🔧 Soft Starter',
    'inverter': '🔄 Inversor'
  };
  return labels[type] || type;
}

function getBreakerFromCurrent(current) {
  const ratings = [10, 16, 20, 25, 32, 40, 50, 63, 80, 100, 125, 160, 200];
  const breaker = ratings.find(r => current <= r) || ratings[ratings.length - 1];
  return `${breaker} A`;
}

function getCableSizeFromCurrent(current) {
  if (current <= 20) return '2,5 mm²';
  if (current <= 32) return '4 mm²';
  if (current <= 45) return '6 mm²';
  if (current <= 60) return '10 mm²';
  if (current <= 80) return '16 mm²';
  if (current <= 100) return '25 mm²';
  if (current <= 125) return '35 mm²';
  if (current <= 150) return '50 mm²';
  return '70 mm² ou mais';
}

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  loadProjects();
  
  document.getElementById('inputMode').addEventListener('change', updateInputMode);
  
  document.getElementById('partidaForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    addPartida(formData);
  });
  
  document.getElementById('fatorCagaco').addEventListener('change', () => {
    renderResults();
  });
  
  updateInputMode();
});

# 🚀 Guia Rápido de Início

## Opção 1: Usando Script (RECOMENDADO)

### Windows
1. Navegue até a pasta do projeto no terminal
2. Execute:
   ```cmd
   run.bat
   ```
   Isso vai:
   - Criar uma pasta `venv` (ambiente virtual)
   - Instalar dependências
   - Iniciar a aplicação

3. Acesse `http://localhost:5000` no navegador

### Linux/Mac
```bash
chmod +x run.sh
./run.sh
```

---

## Opção 2: Manual

### 1. Instalar Python
- Certifique-se que Python 3.9+ está instalado
- Verifique: `python --version`

### 2. Criar Ambiente Virtual
```bash
python -m venv venv
```

### 3. Ativar Ambiente
**Windows:**
```cmd
venv\Scripts\activate.bat
```

**Linux/Mac:**
```bash
source venv/bin/activate
```

### 4. Instalar Dependências
```bash
pip install -r requirements.txt
```

### 5. Executar Aplicação
```bash
python app.py
```

### 6. Acessar
Abra o navegador e vá para:
```
http://localhost:5000
```

---

## ⚡ Próximos Passos

1. **Primeiro uso**: A primeira vez que acessar, um projeto padrão será criado
2. **Adicione partidas**: Preencha o formulário e clique em "Adicionar"
3. **Visualize resultados**: Os cálculos aparecem em tempo real na coluna direita
4. **Salve**: Tudo é salvo automaticamente em `dados.json`

---

## 🎨 Personalizações

### Trocar porta (padrão é 5000)
Edite o final de `app.py`:
```python
if __name__ == '__main__':
    app.run(debug=True, port=5001)  # Mudou para 5001
```

### Desativar debug mode (produção)
```python
if __name__ == '__main__':
    app.run(debug=False, port=5000)
```

---

## 🔍 Troubleshooting

| Problema | Solução |
|----------|---------|
| `ModuleNotFoundError: No module named 'flask'` | Execute `pip install -r requirements.txt` |
| `Port 5000 already in use` | Use outra porta (veja seção Personalizações) |
| `Python not found` | Instale Python ou adicione ao PATH |
| Os dados não salvam | Verifique permissões de escrita na pasta |

---

## 📊 Melhorias Implementadas vs Versão JavaScript

✅ Backend robusto em Python  
✅ Persistência de dados em JSON  
✅ API RESTful para operações  
✅ Design melhorado com gradientes e animações  
✅ Tema claro/escuro aprimorado  
✅ Interface mais intuitiva  
✅ Código mais limpo e mantível  

---

**Pronto para dimensionar partidas? 🎉**

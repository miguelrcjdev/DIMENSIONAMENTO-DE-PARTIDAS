#!/bin/bash

echo ""
echo "==============================================="
echo "  Dimensionamento de Partidas Eletricas"
echo "  Iniciando aplicacao..."
echo "==============================================="
echo ""

# Criar ambiente virtual se não existir
if [ ! -d "venv" ]; then
    echo "Criando ambiente virtual..."
    python3 -m venv venv
    source venv/bin/activate
    echo "Instalando dependencias..."
    pip install -r requirements.txt
else
    source venv/bin/activate
fi

echo ""
echo "Iniciando servidor Flask..."
echo ""
echo "Acesse: http://localhost:5000"
echo ""

python app.py

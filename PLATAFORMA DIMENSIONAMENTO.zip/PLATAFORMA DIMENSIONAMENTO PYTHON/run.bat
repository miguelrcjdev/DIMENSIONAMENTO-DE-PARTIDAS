@echo off
REM Script para iniciar a aplicação no Windows

echo.
echo ===============================================
echo   Dimensionamento de Partidas Eletricas
echo   Iniciando aplicacao...
echo ===============================================
echo.

REM Criar ambiente virtual se não existir
if not exist venv (
    echo Criando ambiente virtual...
    python -m venv venv
    call venv\Scripts\activate.bat
    echo Instalando dependencias...
    pip install -r requirements.txt
) else (
    call venv\Scripts\activate.bat
)

echo.
echo Iniciando servidor Flask...
echo.
echo Acesse: http://localhost:5000
echo.

python app.py

pause

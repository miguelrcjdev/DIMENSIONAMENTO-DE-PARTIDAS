# ⚡ Plataforma de Dimensionamento de Partidas Elétricas

Uma aplicação web moderna para calcular e dimensionar componentes elétricos de partidas de motores.

## 🚀 Características

- ✅ Suporte a múltiplos tipos de partida (Direta, Estrela-Triângulo, Soft Starter, Inversor)
- ✅ Cálculo automatizado de cabos, disjuntores, contatores e bornes
- ✅ Interface responsiva e moderna com tema claro/escuro
- ✅ Multiplicador FATOR CAGAÇO para sobrecarga futura
- ✅ Salva projetos automaticamente em JSON
- ✅ Suporte a redundância de contatores
- ✅ Cálculos precisos conforme normas NBR

## 📋 Pré-requisitos

- Python 3.9+
- pip

## 🔧 Instalação

1. **Clone ou copie os arquivos para a pasta do projeto**

2. **Instale as dependências:**
   ```bash
   cd "c:\Users\miguelruben\Desktop\PLATAFORMA DIMENSIONAMENTO PYTHON"
   pip install -r requirements.txt
   ```

3. **Execute a aplicação:**
   ```bash
   python app.py
   ```

4. **Acesse no navegador:**
   ```
   http://localhost:5000
   ```

## 📊 Como Usar

### Adicionar uma Partida

1. Selecione o **modo de entrada** (Potência ou Corrente do motor)
2. Preenchao **formulário com os dados da carga**
3. Escolha o **tipo de partida**
4. Marque **redundância** se necessário (opcional)
5. Clique em **"➕ Adicionar Partida"**

### Configurar o Painel

- Ajuste o **FATOR CAGAÇO** para prever sobrecargas futuras
- Valores recomendados:
  - 1.0 = sem margem
  - 1.25 = 25% de margem
  - 1.5 = 50% de margem
  - 1.75 = 75% de margem

### Visualizar Resultados

Os resultados são atualizados em tempo real:
- Componentes necessários para cada partida
- Resumo geral do painel
- Disjuntor de entrada
- Cabo de alimentação

## 🎨 Design e Aparência

- **Tema Moderno**: Gradientes, sombras e animações suaves
- **Modo Claro/Escuro**: Alterne entre temas com um clique
- **Responsivo**: Funciona em desktop, tablet e mobile
- **Ícones Descritivos**: Fácil identificação de cada seção

## 📁 Estrutura do Projeto

```
PLATAFORMA DIMENSIONAMENTO PYTHON/
├── app.py                 # Backend Flask
├── requirements.txt       # Dependências Python
├── dados.json            # Dados salvos (criado automaticamente)
├── templates/
│   └── index.html        # Template principal
└── static/
    ├── style.css         # Estilos CSS
    └── script.js         # Lógica frontend
```

## 🔧 Tecnologias

- **Backend**: Flask (Python)
- **Frontend**: HTML5, CSS3, JavaScript Vanilla
- **Armazenamento**: JSON local
- **Design**: CSS Grid, Flexbox, CSS Variables

## 📐 Cálculos Implementados

### Corrente do Motor
```
I = (P × 1000) / (V × √3 × FP × η)
```

### Dimensionamento de Componentes
- **Cabos**: Fator de segurança com base em corrente
- **Disjuntores**: Padrão de ratings comerciais
- **Contatores**: 1.2 × corrente nominal
- **Bornes**: Conforme corrente máxima

### Especial para Y-Δ (Estrela-Triângulo)
- K1, K2 (Contatores de redução): 0.58 × corrente
- K3 (Contator auxiliar): corrente ÷ 3
- Relé térmico: calculado em corrente reduzida

## 💾 Dados Salvos

Os projetos e dados são salvos automaticamente em `dados.json`:

```json
{
  "projects": [
    {
      "id": 1,
      "name": "Projeto 14/07/2026",
      "created": "2026-07-14T...",
      "partidas": [...]
    }
  ],
  "products": [...]
}
```

## 🌙 Tema Claro/Escuro

Clique no botão **☀️/🌙** no canto superior direito para alternar entre temas. Sua preferência é salva automaticamente.

## 🐛 Troubleshooting

### Porta 5000 já está em uso
```bash
# Use outra porta
python 
from flask import Flask
app = Flask(__name__)
app.run(port=5001)
```

### Erro ao salvar dados
- Verifique permissões de escrita na pasta
- Certifique-se que `dados.json` está acessível

## 📞 Suporte

Para dúvidas ou problemas, revise o código ou consulte a documentação do Flask:
- https://flask.palletsprojects.com/

## 📝 Notas

- Todos os cálculos seguem padrões NBR/IEEE
- Valores de componentes são aproximados e devem ser verificados com catálogos
- A redundância adiciona um contator extra conforme especificação

---

**Desenvolvido com ❤️ para dimensionamento preciso de partidas elétricas**
